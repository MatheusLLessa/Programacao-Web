package sptech.school.exerciciofilme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioFilmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
