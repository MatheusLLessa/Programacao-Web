package sptech.school.exerciciofilme.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.exerciciofilme.Enitity.Filme;

public interface FilmeRepository extends JpaRepository<Filme, Integer> {
}
