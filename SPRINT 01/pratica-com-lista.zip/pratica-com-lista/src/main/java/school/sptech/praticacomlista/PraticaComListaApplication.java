package school.sptech.praticacomlista;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraticaComListaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraticaComListaApplication.class, args);
	}

}
