package school.sptech.estoque01222143matheuslessa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Estoque01222143MatheuslessaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Estoque01222143MatheuslessaApplication.class, args);
	}

}
