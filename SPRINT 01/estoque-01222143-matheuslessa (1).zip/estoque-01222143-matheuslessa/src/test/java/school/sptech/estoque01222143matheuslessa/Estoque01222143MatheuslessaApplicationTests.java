package school.sptech.estoque01222143matheuslessa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Estoque01222143MatheuslessaApplicationTests {

	@Test
	void contextLoads() {
	}

}
